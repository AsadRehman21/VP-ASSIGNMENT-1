﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication5
{
    class studentProfile
    {
      public int ID { get; set; }
     public string Name { get; set; }
       public int Semester { get; set; }
        public Double CGPA { get; set; }
    public string Department { get; set; }
     public string University { get; set; }
     public char attendance { get; set; }
    }
    
    class Program
    {
       
      
        static void Main(string[] args)
        {

            string fileName = @"C:\Users\Asad Rehman\Documents\Visual Studio 2013\Projects\ConsoleApplication5\ConsoleApplication5\MC.bin";
            string fileName2 = @"C:\Users\Asad Rehman\Documents\Visual Studio 2013\Projects\ConsoleApplication5\ConsoleApplication5\MC2.bin";
            int size=0, z, m = 0;
            studentProfile[] s = new studentProfile[size] ;
            studentProfile[] s1 = new studentProfile[size];
            int choice,choice2;
            char chr = 'y';
           
            while (chr == 'y')
            {
          Console.WriteLine("*******************************************PLEASE SELECT MENU***********************************************************");
          Console.Write("\n");
          Console.WriteLine("                                      _____________________________ ");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |1.| Create Student profile   |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |2.| Search Student           |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |3.| Delete Student Record    |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |4.| List top 03 of class     |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |5.| Mark student attendance  |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |6.| View attendance          |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |7.| Exit                     |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.Write("\n");
          Console.Write("                                      SELECT OPTION : ");

           choice=Convert.ToInt32(Console.ReadLine());
           Console.Clear();

          
               switch (choice)
               {
                   case 1:
                       Console.Write ("HOW MANY PROFILE YOU WANT TO CREATE  :    ");
                       size = Convert.ToInt32(Console.ReadLine());
                       Console.Write("\n");
                       s = new studentProfile[size];
                       s1 = new studentProfile[size];
                       for (int i = 0; i < size; i++)
                       {

                           Console.Write("STUDENT ID  :    ");
                           z = Convert.ToInt32(Console.ReadLine());
                           for (int j = 0; j < i; j++)
                           {
                               if (s[j].ID == z)
                               {
                                   m = 1;
                                   break;
                               }
                           }
                           if (m == 0)
                           {
                               s[i] = new studentProfile();
                               s[i].ID = z;
                               Console.Write("STUDENT  NAME  :   ");
                               s[i].Name = Convert.ToString(Console.ReadLine());
                               Console.Write("STUDENT   SEMESTER  :   ");
                               s[i].Semester = Convert.ToInt32(Console.ReadLine());
                               Console.Write("STUDENT   CGPA   :    ");
                               s[i].CGPA = Convert.ToDouble(Console.ReadLine());
                               Console.Write("STUDENT    DEPARTMENT    :    ");
                               s[i].Department = Convert.ToString(Console.ReadLine());
                               Console.Write("STUDENT   UNIVERSITY     :   ");
                               s[i].University = Convert.ToString(Console.ReadLine());
                               if (File.Exists(fileName))
                               {
                                   using (BinaryWriter writer = new BinaryWriter(File.Open(fileName, FileMode.Append)))
                                   {

                                       writer.Write(s[i].ID);
                                       writer.Write( s[i].Name);
                                       writer.Write( s[i].Semester);
                                       writer.Write(s[i].CGPA);
                                       writer.Write( s[i].Department);
                                       writer.Write(s[i].University);
                                           writer.Flush();

                                   }
                               }
                               else
                               {
                                   using (BinaryWriter writer = new BinaryWriter(File.Open(fileName, FileMode.Create)))
                                   {

                                       writer.Write(s[i].ID);
                                       writer.Write(s[i].Name);
                                       writer.Write(s[i].Semester);
                                       writer.Write(s[i].CGPA);
                                       writer.Write(s[i].Department);
                                       writer.Write(s[i].University);
                                       writer.Flush();
                                   }
                               }
                           }
                           else
                           {
                               Console.WriteLine("STUDENT  ID ALREADY EXIST PLEASE RE_ENTER YOUR ID");
                               i--;
                               m = 0;
                               continue;
                           }


                       }


                       break;
                   case 2:
                        Console.WriteLine("*******************************************PLEASE SELECT MENU***********************************************************");
          Console.Write("\n");
          Console.WriteLine("                                      _____________________________ ");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |1.| Search By ID             |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |2.| Search By Name           |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |3.| Total No. Of Student     |");
          Console.WriteLine("                                     |__|__________________________|");
          Console.WriteLine("                                     |  |                          |");
          Console.WriteLine("                                     |4.| Back To Main Menu        |");
          Console.WriteLine("                                     |__|__________________________|");
         
          Console.Write("\n");
          Console.Write("                                      SELECT OPTION : ");
                      
                       choice2 = Convert.ToInt16(Console.ReadLine());
                       Console.Clear();
                       int t = 0;
                       switch (choice2)
                       {
                           case 1:
                               int ID;
                               int x,sem;
                               Double cg;
                               string nam,dept,uni;
                               Console.Write("Enter ID Please  :  ");
                               ID = Convert.ToInt16(Console.ReadLine());
                               if (File.Exists(fileName))
                               {
                                   using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
                                   {
                                       while (reader.BaseStream.Position != reader.BaseStream.Length)
                                       {
                                           // It is importan

                                           x = reader.ReadInt32();
                                           nam = reader.ReadString();
                                           sem = reader.ReadInt32();
                                           cg = reader.ReadDouble();
                                           dept = reader.ReadString();
                                           uni = reader.ReadString();
                                           if (x == ID)
                                           {
                                               t = 1;
                                               Console.WriteLine(String.Format("{0,-10}  {1,20}  {2,12}   {3,13}  {4,23}  {5,25}", x, nam, sem, cg, dept, uni));
                                               break;
                                           }
                                       }
                                   }
                               }
                                 
                             
                              
                                     if(t==0)
                                     {
                                         Console.WriteLine("NOT FOUND");
                                     }
                                     else
                                     {
                                         t = 0;
                                     }
                                     try
                                     {
                                       }
                                   catch (Exception e)
                                   {
                                       Console.WriteLine("OBJECT IS NOT DEFINED ",e);
                                   }
                               
                               break;
                           case 2:
                               string name;
                               Console.Write("Enter Name Please  :    ");
                               name = Console.ReadLine();
                               
                                 
                                    int x1,sem1;
                               Double cg1;
                               string nam1,dept1,uni1;
                               
                               if (File.Exists(fileName))
                               {
                                   using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
                                   {
                                       while (reader.BaseStream.Position != reader.BaseStream.Length)
                                       {
                                           // It is importan

                                           x1 = reader.ReadInt32();
                                           nam1 = reader.ReadString();
                                           sem1 = reader.ReadInt32();
                                           cg1 = reader.ReadDouble();
                                           dept1 = reader.ReadString();
                                           uni1 = reader.ReadString();
                                           if (nam1 == name)
                                           {
                                               t = 1;
                                               Console.WriteLine(String.Format("{0,-10}  {1,20}  {2,12}   {3,13}  {4,23}  {5,25}", x1, nam1, sem1, cg1, dept1, uni1));
                                               break;
                                           }
                                       }
                                   }
                               }
                                 
                             
                              
                                     if(t==0)
                                     {
                                         Console.WriteLine("NOT FOUND");
                                     }
                                     else
                                     {
                                         t = 0;
                                     }
                                     
                               try
                               {
                                     if(t==1)
                                     {

                                     }
                                       }
                                   catch (Exception e)
                                   {
                                       Console.WriteLine("OBJECT IS NOT DEFINED ",e);
                                   }
                               break;
                           case 3:
                           
 Console.WriteLine(String.Format("{0,-10}  {1,20}  {2,12}   {3,13}  {4,23}  {5,25}", "ID", "NAME", "SEMESTER", "CGPA", "DEPARTMENT", "UNIVERSITY"));
                               Console.WriteLine("\n");
                               int x2, sem2;
                               Double cg2;
                               string nam2, dept2, uni2;

                               if (File.Exists(fileName))
                               {
                                   using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
                                   {
                                       while (reader.BaseStream.Position != reader.BaseStream.Length)
                                       {
                                           // It is importan

                                           x2 = reader.ReadInt32();
                                           nam2 = reader.ReadString();
                                           sem2 = reader.ReadInt32();
                                           cg2 = reader.ReadDouble();
                                           dept2 = reader.ReadString();
                                           uni2 = reader.ReadString();

                                           Console.WriteLine(String.Format("{0,-10}  {1,20}  {2,12}   {3,13}  {4,23}  {5,25}", x2, nam2, sem2, cg2, dept2, uni2));

                                       }
                                   }
                               }
                               break;
                           case 4:
                              
                               break;
                              
                       }
                       break;
                   case 3:
                         int id;
                         int h = 0;
                        int l = 0;
                               Console.Write("Enter ID Please  :    ");
                               id = Convert.ToInt16(Console.ReadLine());
                          int x3,sem3;
                               Double cg3;
                               string nam3,dept3,uni3;
                               if (File.Exists(fileName))
                               {
                                   using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
                                   {
                                       s1 = new studentProfile[reader.BaseStream.Length];
                                       while (reader.BaseStream.Position != reader.BaseStream.Length)
                                       {
                                           // It is importan

                                           x3 = reader.ReadInt32();
                                           nam3 = reader.ReadString();
                                           sem3 = reader.ReadInt32();
                                           cg3 = reader.ReadDouble();
                                           dept3 = reader.ReadString();
                                           uni3 = reader.ReadString();
                                           if (x3 != id)
                                           {
                                              
                                               s1[l] = new studentProfile();
                                               s1[l].ID = x3;
                                               s1[l].Name= nam3;
                                               s1[l].Semester= sem3;
                                               s1[l].CGPA = cg3;
                                               s1[l].Department= dept3;
                                               s1[l].University= uni3;
                                               l++;
                                           }
                                           if(x3==id)
                                           {
                                               h = 1;
                                           }
                                       }
                                   }
                               }

                               using (BinaryWriter writer = new BinaryWriter(File.Open(fileName, FileMode.Create)))
                               {
                               for (int i = 0; i < l; i++)
                               {

                                
                                
                                  

                                       writer.Write(s1[i].ID);
                                       writer.Write(s1[i].Name);
                                       writer.Write(s1[i].Semester);
                                       writer.Write(s1[i].CGPA);
                                       writer.Write(s1[i].Department);
                                       writer.Write(s1[i].University);
                                       writer.Flush();
                                   }
                               if (h == 1)
                               {
                                   Console.WriteLine("                                            Deleted succesfully                     ");
                               }
                               else {
                                   Console.WriteLine("                                   NOT DELETED PLEASE ENTER VALID ID ");
                                       }
                                   }
                       break;
                   case 4:
                       Double a=0, b=0, c=0; 
                          int x4,sem4;
                               Double cg4;
                               string nam4,dept4,uni4;

                               if (File.Exists(fileName))
                               {
                                   using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
                                   {
                                      
                                       while (reader.BaseStream.Position != reader.BaseStream.Length)
                                       {
                                           // It is importan

                                           x4 = reader.ReadInt32();
                                           nam4 = reader.ReadString();
                                           sem4 = reader.ReadInt32();
                                           cg4 = reader.ReadDouble();
                                           dept4 = reader.ReadString();
                                           uni4 = reader.ReadString();
                                           if (cg4 > a)
                                           {
                                               c = b;
                                               b = a;
                                               a = cg4;
                                           }
                                           else if (cg4 < a)
                                           {

                                               if (cg4 < b)
                                               {
                                                   if (cg4 > c)
                                                   {
                                                       c = cg4;
                                                   }
                                               }
                                               else
                                               {
                                                   c = b;
                                                   b = cg4;
                                               }
                                           }

                                       }
                                   }

                               }

                       Console.WriteLine("First Highest CGPA is = "+a);
                       Console.WriteLine("Second Highest CGPA is = "+b);
                       Console.WriteLine("Third Highest CGPA is = "+c);
                           break;
                   case 5:
                           char at;
                           Console.WriteLine(String.Format("{0,-10}  {1,14} {2,27}", "ID ", "NAME","ATTENDANCE"));
                       int x5,sem5;
                               Double cg5;
                               string nam5,dept5,uni5;

                               if (File.Exists(fileName))
                               {
                                   using (BinaryReader reader = new BinaryReader(File.Open(fileName, FileMode.Open)))
                                   {
                                       using (BinaryWriter writer = new BinaryWriter(File.Open(fileName2, FileMode.Create)))
                                       {
                                           while (reader.BaseStream.Position != reader.BaseStream.Length)
                                           {
                                               // It is importan

                                               x5 = reader.ReadInt32();
                                               nam5 = reader.ReadString();
                                               sem5 = reader.ReadInt32();
                                               cg5 = reader.ReadDouble();
                                               dept5 = reader.ReadString();
                                               uni5 = reader.ReadString();
                                               Console.Write(String.Format("{0,-18}  {1,6}", x5, nam5 ));
                                               Console.Write("\t\t\t");
                                               at = Convert.ToChar(Console.ReadLine());
                                               if (at == 'A' || at == 'P')
                                               {
                                                   if (File.Exists(fileName))
                                                   {


                                                       writer.Write(x5);
                                                       writer.Write(nam5);
                                                       writer.Write(at);
                                                       writer.Flush();

                                                   }
                                               }
                                               else
                                               {
                                                   Console.WriteLine("Incorrect Marked Attendance Please ReMarked it Again");
                                                   reader.BaseStream.Position -= 33;
                                               }
                                           }
                                       }

                                   }
                               }
                           
                       break;
                   case 6:
                        Console.WriteLine(String.Format("{0,-10}  {1,20} {2,28}", "ID ", "NAME","ATTENDANCE"));
                        int x6;
                        char at6;
                               string nam6;

                               if (File.Exists(fileName))
                               {
                                   using (BinaryReader reader = new BinaryReader(File.Open(fileName2, FileMode.Open)))
                                   {

                                       while (reader.BaseStream.Position != reader.BaseStream.Length)
                                       {
                                           // It is importan

                                           x6 = reader.ReadInt32();
                                           nam6 = reader.ReadString();
                                           at6 = reader.ReadChar();
                                           Console.WriteLine(String.Format("{0,-10}  {1,20} {2,24}", x6, nam6, at6));
                       
                                       }
                                   }
                               }
                       
                          
                       break;
                   case 7:
                       Environment.Exit(0);
                       break;
               }
               Console.WriteLine("Want Continue  : y/n?? ");
               chr=Convert.ToChar(Console.ReadLine());
               Console.Clear();
           }

           Console.ReadKey();

        }
        
    }
}
